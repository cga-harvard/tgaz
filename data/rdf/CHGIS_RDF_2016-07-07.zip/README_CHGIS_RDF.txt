CHGIS Gazetteer RDF listing

generated:  2016-07-07

size:  37MB

records:  71712

UPDATE:  Changed URL to correct base URL  maps.cga.harvard.edu  

UPDATE:  RDF format was updated per email of 2015-03-31 from Rainer Simon.

UPDATE:  Fixed 2 rows with incorrect x, y values = 105.781

NOTES:   This listing of CHGIS gazetteer records conforms to the Pelagios RDF Interchange Format.    This is a snapshot for the purposes of holding a local copy of the index in other applications.   Please use the URI at the beginning of each record to find the current complete record.   Note, the default format is currently set to HTML.   Other formats are available:

[HTML]   http://chgis.hmdc.harvard.edu/placename/hvd_49

[XML]   http://chgis.hmdc.harvard.edu/placename/xml/hvd_49

[JSON]   http://chgis.hmdc.harvard.edu/placename/json/hvd_49

[RDF]   http://chgis.hmdc.harvard.edu/placename/rdf/hvd_49


Gazetteer service homepage:  http://chgis.hmdc.harvard.edu/tgaz/   

Contact:  Lex Berman  (chgis AT fas.harvard.edu)